package com.assignment.HRViewer.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.assignment.HRViewer.constants.ResourceUri;
import com.assignment.HRViewer.model.Employee;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.CSVReader;

@Controller
public class employeeManagementScreenController {
	
	private RestTemplate restTemplate;
	private HttpHeaders headers;
	
	
	@InitBinder
	public void initBinder(WebDataBinder databinder){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		databinder.registerCustomEditor(Date.class,"dateOfBirth",new CustomDateEditor(dateFormat, false));
	}
	
	@RequestMapping(value = "toEdit", method = RequestMethod.GET, params={"employeeCode"})
	public ModelAndView getEditScreen(HttpSession session, @RequestParam("employeeCode") Long employeeCode) {
		Long userId = (Long) session.getAttribute("userId");
		Employee employeeToUpdate = getEmployeeToUpdate(userId, employeeCode);
		ModelAndView modelAndView = new ModelAndView("employeeDataEditorScreen");
		modelAndView.addObject("employeeToUpdate", employeeToUpdate);
		return modelAndView;
	}
	
	/*
	 * Method to get Employee Data that needs to be updated
	 */
	private Employee getEmployeeToUpdate(Long userId, Long employeeCode) {
		restTemplate = new RestTemplate();
		Employee employee = restTemplate.getForObject(ResourceUri.GET_BY_CODE_URL+userId+"/employeeCode/"+employeeCode, Employee.class);
		return employee;
	}

	@RequestMapping(value = "edit", method = RequestMethod.POST)
	public ModelAndView editScreen(HttpSession session, @Valid @ModelAttribute("employee") Employee employee, BindingResult bindingResult) {
		ModelAndView modelAndView = null;
		if(bindingResult.hasErrors()) {
			System.out.println(bindingResult.getAllErrors());
			// Return view with binding errors
			modelAndView = new ModelAndView("employeeDataEditorScreen",bindingResult.getModel());
		}else {
			String jsonStr = null;
			modelAndView = new ModelAndView("employeeManagementScreen");
			// Creating Object of ObjectMapper define in Jakson Api
	        ObjectMapper Obj = new ObjectMapper();
	        // Object of JsonNode which will be used for response parsing
	        Long userId;
	        // Creating an abject of ModelAndView
	        try {
	            // get Oraganisation object as a json string
	            jsonStr = Obj.writeValueAsString(employee);
	            // Displaying JSON String
	            System.out.println(jsonStr);
	        }
	 
	        catch (IOException e) {
	        	System.out.println(e.getMessage());
	            e.printStackTrace();
	        }
	        restTemplate = new RestTemplate();
	        // Instantiate headers
			headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    userId = (Long) session.getAttribute("userId");
		    
		    HttpEntity<String> request = 
		    	      new HttpEntity<String>(jsonStr.toString(), headers);
		    // request to update
		    restTemplate.put(ResourceUri.UPDATE_URL + userId, request);
		    
		}
				
		return modelAndView;
	}
	
	@RequestMapping(value = "cancel", method = RequestMethod.GET)
	public ModelAndView onClick() {
		return new ModelAndView("employeeManagementScreen");
	}
	
	@RequestMapping(value="upload" , method = RequestMethod.POST)
	public String uploadEmployeeData(HttpSession session, @RequestParam("file") MultipartFile file, Model model) {
		List<Employee> employeeList = new ArrayList<>();
		
        if (file.isEmpty()) {
            model.addAttribute("message", "Please select a CSV file to upload.");
        } else {

            // parse CSV file to create a list of `User` objects
            try (Reader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {            	

            	@SuppressWarnings("resource")
				CSVReader csvReader = new CSVReader(reader); 
            	csvReader.skip(1);
            	String[] next;
            	while((next = csvReader.readNext()) != null) {
            		employeeList.add(new Employee(Long.parseLong(next[0]), next[1], next[2], next[3], (Date) new SimpleDateFormat("dd-MM-yyyy").parse(next[4])));
            	}

                boolean isUploaded = uploadEmployees(employeeList, session);
                if(isUploaded) {
                	model.addAttribute("message", "Uploaded Successfully");
                } else {
                	model.addAttribute("message", "Upload failed");
                }


            } catch (Exception ex) {
                model.addAttribute("message", "An error occurred while processing the CSV file.");
            }
        }
        return "employeeManagementScreen";
	}
	
	private boolean uploadEmployees(List<Employee> employeeList, HttpSession session) {
		ObjectMapper mapper = new ObjectMapper();
		boolean isUploaded;
		String employeeListAsJson = "";
	    try {
	    	employeeListAsJson = mapper.writeValueAsString(employeeList);
	    	System.out.println(employeeListAsJson);
		} catch (JsonProcessingException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	    int statusCodeValue = 0;
	    Long userId = (Long) session.getAttribute("userId");
	    JsonNode root = null;
	    restTemplate = new RestTemplate();
		headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    
	    HttpEntity<String> request = 
	    	      new HttpEntity<String>(employeeListAsJson, headers);
	    System.out.println("Here");
	    ResponseEntity<String> additionResultAsJson = restTemplate.postForEntity(ResourceUri.UPLOAD_EMPLOYEE_LIST_URL+userId, request, String.class);
	    // Trying to parse the Response Json
	    System.out.println(additionResultAsJson);
	    try {
			root = mapper.readTree(additionResultAsJson.getBody());
			statusCodeValue = root.path("statusCodeValue").asInt();
		} catch (JsonProcessingException e) {
			System.out.println("Error while parsing!");
			e.printStackTrace();
		}
	    
	    if(statusCodeValue == 201) {
	    	
	    	isUploaded = true;
	    } else {
	    	isUploaded = false;
	    }
	    return isUploaded;
	}
	
}
