package com.assignment.HRViewer.model;

import javax.validation.constraints.Size;

public class User {
	
	private Long userId;
	@Size(min = 5, max = 50, message = "length should be in between 5 and 50")
	private String userName;
	@Size(min = 5, max = 50, message = "length should be in between 5 and 50")
	private String password;
	
	public User() {
	}
	
	public User(Long userId, String userName, String password) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
