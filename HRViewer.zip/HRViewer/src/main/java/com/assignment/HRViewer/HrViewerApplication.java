package com.assignment.HRViewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.assignment.HRViewer")
public class HrViewerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrViewerApplication.class, args);
	}

}
