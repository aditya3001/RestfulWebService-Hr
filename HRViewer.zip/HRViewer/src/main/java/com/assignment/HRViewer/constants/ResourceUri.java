package com.assignment.HRViewer.constants;

public class ResourceUri {
	
	public final static String AUTH_URL = "http://localhost:8081/userResource/userAuth";
	public final static String GET_BY_CODE_URL = "http://localhost:8081/employeeResource/getEmployeeByCode/user/";
	public final static String FETCH_EMPLOYEE_URL = "http://localhost:8081/employeeResource/getEmployees/user/";	
	public final static String UPDATE_URL = "http://localhost:8081/employeeResource/updateEmployee/user/";
	public final static String UPLOAD_EMPLOYEE_LIST_URL = "http://localhost:8081/employeeResource/addEmployeeList/user/";
			
}
