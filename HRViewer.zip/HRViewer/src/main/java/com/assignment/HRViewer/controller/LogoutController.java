package com.assignment.HRViewer.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LogoutController {

	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public ModelAndView fetchLoginDetails(HttpSession session) {
		session.removeAttribute("userName");
		session.removeAttribute("userId");
		session.invalidate();
		// Storing Validation result
		ModelAndView modelAndView = new ModelAndView("loginScreen");
		// Rendering mainUtility screen or login screen based on validation result
		return modelAndView;
	}
	
}
