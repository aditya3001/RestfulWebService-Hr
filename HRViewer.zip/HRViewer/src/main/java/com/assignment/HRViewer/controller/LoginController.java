package com.assignment.HRViewer.controller;

import java.io.IOException;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.assignment.HRViewer.constants.ResourceUri;
import com.assignment.HRViewer.model.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
public class LoginController {
	private RestTemplate restTemplate;
	private HttpHeaders headers;
		
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView getLoginDetails() {
		return new ModelAndView("loginScreen");
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView fetchLoginDetails(HttpSession session, @Valid @ModelAttribute("user") User user, BindingResult bindingResult) {
		ModelAndView modelAndView = null;
		if(bindingResult.hasErrors()) {
			// return view with errors
			modelAndView = new ModelAndView("loginScreen",bindingResult.getModel());
		} else {
			modelAndView = prepareModelAndView(session, user);
		}
		// Rendering mainUtility screen or login screen based on validation result
		return modelAndView;
	}
	
	/*
	 * Method to Authenticate the user and prepare view based on authentication result
	 */
	private ModelAndView prepareModelAndView(HttpSession session, User user) {
		
		// To store object as JsonString
		String jsonStr = null;
		String msg;
		// Creating Object of ObjectMapper define in Jakson Api
        ObjectMapper Obj = new ObjectMapper();
        // Object of JsonNode which will be used for response parsing
        JsonNode root = null;
        Long userId;
        // Creating an abject of ModelAndView
        ModelAndView modelAndView = new ModelAndView();
        try {
            // get Oraganisation object as a json string
            jsonStr = Obj.writeValueAsString(user);
            // Displaying JSON String
            System.out.println(jsonStr);
        }
 
        catch (IOException e) {
        	System.out.println(e.getMessage());
            e.printStackTrace();
        }
        restTemplate = new RestTemplate();
		headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    
	    HttpEntity<String> request = 
	    	      new HttpEntity<String>(jsonStr.toString(), headers);
	    
	    ResponseEntity<String> authResultAsJson = restTemplate.postForEntity(ResourceUri.AUTH_URL, request, String.class);
	    // Trying to parse the Response Json
	    try {
			root = Obj.readTree(authResultAsJson.getBody());
			userId = root.path("body").asLong();
		} catch (JsonProcessingException e) {
			userId = 0L;
			System.out.println("Error while parsing!");
			e.printStackTrace();
		}
	    //Fetch status code value
		int statusCodeValue = root.path("statusCodeValue").asInt();
	    if(statusCodeValue == 200) {
		
	    	//Set userName and userId as global attribute
	    	session.setAttribute("userName", user.getUserName());
	    	session.setAttribute("userId", userId);

	    	modelAndView.addObject("userName", user.getUserName());
	    	//set view
	    	modelAndView.setViewName("employeeManagementScreen");
	    } else {
	    	// To show error on login page
	    	msg = "Invalid UserName or Password!";
	    	modelAndView = new ModelAndView("loginScreen");
			modelAndView.addObject("output", msg);
	    }
		
	    return modelAndView;
	}
}
