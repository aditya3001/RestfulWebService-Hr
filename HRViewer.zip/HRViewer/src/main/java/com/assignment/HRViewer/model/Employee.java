package com.assignment.HRViewer.model;

import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Employee {
	
	/**
	 * 
	 */
	private Long employeeCode;
	@NotBlank(message = "Cannot be blank")
	@Size(max = 100, message = "Cannot be greater than 100 letters")
	private String employeeName;
	@Size(max = 500, message = "Cannot be greater than 500 letters")
	private String location;
	@Pattern(regexp = "^(.+)@(.+)",message="should be valid")
	private String email;
	private Date dateOfBirth;
	
	
	public Employee(Long employeeCode, String employeeName, String location, String email, Date dateOfBirth) {
		super();
		this.employeeCode = employeeCode;
		this.employeeName = employeeName;
		this.location = location;
		this.email = email;
		this.dateOfBirth = dateOfBirth;
	}

	
	public Employee() {
	}
	
	public Long getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(Long employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
}