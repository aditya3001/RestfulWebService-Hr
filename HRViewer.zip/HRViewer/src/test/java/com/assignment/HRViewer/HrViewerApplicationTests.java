package com.assignment.HRViewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrViewerApplicationTests {

	@Test
	void contextLoads() {
	}

}
