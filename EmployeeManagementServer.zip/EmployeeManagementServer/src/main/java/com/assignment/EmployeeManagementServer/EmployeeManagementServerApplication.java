package com.assignment.EmployeeManagementServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementServerApplication.class, args);
	}

}
