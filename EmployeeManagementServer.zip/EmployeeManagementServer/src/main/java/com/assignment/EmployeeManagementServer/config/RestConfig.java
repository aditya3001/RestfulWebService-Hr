package com.assignment.EmployeeManagementServer.config;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

import com.assignment.EmployeeManagementServer.resource.EmployeeResource;
import com.assignment.EmployeeManagementServer.resource.UserResource;

@Component
public class RestConfig extends ResourceConfig {

	public RestConfig(Class<?>... classes) {
		register(EmployeeResource.class);
		register(UserResource.class);
	}
	

}
