package com.assignment.EmployeeManagementServer.interfaces;

import org.springframework.http.ResponseEntity;

import com.assignment.EmployeeManagementServer.dto.LoginDto;

public interface UserOperationService {
	
	ResponseEntity<String> validateUser(LoginDto loginUser);
}
