package com.assignment.EmployeeManagementServer.interfaces;

import java.util.List;

import com.assignment.EmployeeManagementServer.model.Employee;

public interface EmployeeOperationService {

	List<Employee> getEmployeeList(Long userId);
	Employee getEmployeeByCode(Long userId, Long employeeCode);
	boolean addEmployeeDetails(Long userId, Employee employee);
	boolean updateEmployeeDetails(Long userId, Employee employee);
	boolean deleteEmployeeDetails(Long userId, Long employeeCode);
	boolean uploadEmployeeList(Long userId, Employee[] employeeList);

}
