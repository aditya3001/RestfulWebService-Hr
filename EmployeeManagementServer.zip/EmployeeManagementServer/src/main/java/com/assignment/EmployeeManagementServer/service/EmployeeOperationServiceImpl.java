package com.assignment.EmployeeManagementServer.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.EmployeeManagementServer.interfaces.EmployeeOperationService;
import com.assignment.EmployeeManagementServer.model.Employee;
import com.assignment.EmployeeManagementServer.model.User;
import com.assignment.EmployeeManagementServer.repository.EmployeeRepository;
import com.assignment.EmployeeManagementServer.repository.UserRepository;

@Service("employeeOperationService")
public class EmployeeOperationServiceImpl implements EmployeeOperationService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee getEmployeeByCode(Long userId, Long employeeCode) {
		return employeeRepository.findByEmployeeCodeAndUserUserId(employeeCode,userId);
	}
	
	@Override
	public List<Employee> getEmployeeList(Long userId) {
//		Long userId = userRepository.findByUsername(userName).getUserId();
		List<Employee> employeeList = employeeRepository.findByUserUserId(userId);
		return employeeList;
	}

	
	@Override
	public boolean addEmployeeDetails(Long userId, Employee employee) {
		Optional<User> user = userRepository.findById(userId);
		boolean isAdded;
		if (user.isPresent()) {
			employee.setUser(user.get());
			// To check whether employee for given employee code exists or not
			if(employeeRepository.existsByEmployeeCodeAndUserUserId(employee.getEmployeeCode(), userId)) {
				System.out.println("Employee Already Exists!");
				isAdded = false;
			} else {
				employeeRepository.save(employee);
				isAdded = true;
			}
		} else {
			isAdded = false;
			System.out.println("User Not Found!");
		}
		
		return isAdded;
		
	}
	
	@Override
	public boolean uploadEmployeeList(Long userId, Employee[] employeeList) {
		Optional<User> user = userRepository.findById(userId);
		boolean isAdded = false;
		if (user.isPresent()) {
			for(Employee employee: employeeList) {
				employee.setUser(user.get());
				// To check whether employee for given employee code exists or not
				if(employeeRepository.existsByEmployeeCodeAndUserUserId(employee.getEmployeeCode(), userId)) {
					System.out.println("Employee Already Exists!");
					isAdded = false;
					continue;
				} else {
					employeeRepository.save(employee);
					isAdded = true;
				}
			}
		} else {
			isAdded = false;
			System.out.println("User Not Found!");
		}
		
		return isAdded;
		
	}

	@Override
	public boolean updateEmployeeDetails(Long userId, Employee updatedEmployee) {
		boolean isUpdated;
		Employee employee = employeeRepository.findByEmployeeCodeAndUserUserId(updatedEmployee.getEmployeeCode(), userId);
		if(employee != null) {
			employee.setEmployeeName(updatedEmployee.getEmployeeName());
			employee.setLocation(updatedEmployee.getLocation());
			employee.setEmail(updatedEmployee.getEmail());
			employee.setDateOfBirth(updatedEmployee.getDateOfBirth());
			employeeRepository.save(employee);
			isUpdated = true;
		}else {
			System.out.println("Employee not present!");
			isUpdated = false;
		}
		return isUpdated;
		
	}

	@Override
	public boolean deleteEmployeeDetails(Long userId, Long employeeCode) {
		Employee employee = employeeRepository.findByEmployeeCodeAndUserUserId(employeeCode, userId);
		boolean isDeleted;
		if(employee != null) {
			System.out.println("Deletion!");
			employeeRepository.delete(employee);
			isDeleted = true;
			System.out.println("Deletion Succeed !");
		}else {
			System.out.println("Deletion Failed !");
			isDeleted = false;
		}
		return isDeleted;
	}


}
