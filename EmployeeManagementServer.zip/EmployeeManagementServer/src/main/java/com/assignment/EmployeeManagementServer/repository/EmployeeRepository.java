package com.assignment.EmployeeManagementServer.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.assignment.EmployeeManagementServer.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	
	List<Employee> findByUserUserId(Long userId);
	Employee findByEmployeeCodeAndUserUserId(Long employeeCode, Long userId);
	boolean existsByEmployeeCodeAndUserUserId(Long employeeCode, Long userId);

}
