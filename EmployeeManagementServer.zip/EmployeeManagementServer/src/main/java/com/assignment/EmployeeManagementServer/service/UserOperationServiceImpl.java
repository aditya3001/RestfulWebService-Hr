package com.assignment.EmployeeManagementServer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.assignment.EmployeeManagementServer.dto.LoginDto;
import com.assignment.EmployeeManagementServer.interfaces.UserOperationService;
import com.assignment.EmployeeManagementServer.model.User;
import com.assignment.EmployeeManagementServer.repository.UserRepository;

@Service("userOperationService")
public class UserOperationServiceImpl implements UserOperationService {

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public ResponseEntity<String> validateUser(LoginDto loginUser) {
		ResponseEntity<String> response;
		
		User user = userRepository.findByUsername(loginUser.getUserName());
		if(user == null) {
			System.out.println("ërror in validateUser method");
			response = new ResponseEntity<>("No such User!", HttpStatus.NOT_FOUND );
			
		} else if(!user.getPassword().equals(loginUser.getPassword())) {
			response = new ResponseEntity<>("Incorrect Password!", HttpStatus.NOT_ACCEPTABLE );
		} else {
			response = new ResponseEntity<>(user.getUserId().toString(), HttpStatus.OK );
		}
		System.out.println(response);
		return response;
	}
	
	
}
