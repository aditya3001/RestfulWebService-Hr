package com.assignment.EmployeeManagementServer.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.assignment.EmployeeManagementServer.interfaces.EmployeeOperationService;
import com.assignment.EmployeeManagementServer.model.Employee;

@Path("/employeeResource")
public class EmployeeResource {

	@Autowired
	private EmployeeOperationService employeeOperationService;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getEmployeeByCode/user/{userId}/employeeCode/{employeeCode}")
	public Employee getEmployeesByCode(@PathParam("userId") Long userId, @PathParam("employeeCode") Long employeeCode) {
		return employeeOperationService.getEmployeeByCode(userId, employeeCode);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getEmployees/user/{userId}")
	public List<Employee> getEmployees(@PathParam("userId") Long userId) {
		return employeeOperationService.getEmployeeList(userId);
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/addEmployee/user/{userId}")
	public ResponseEntity<String> addEmployee(@PathParam("userId") Long userId, Employee employee) {
		ResponseEntity<String> response;
		
		boolean isAdded = employeeOperationService.addEmployeeDetails(userId, employee);
		if(isAdded) {
			response = new ResponseEntity<>("Addition Succeed!", HttpStatus.CREATED );
		}else {
			response = new ResponseEntity<>("Addition Failed!", HttpStatus.CONFLICT );
		}
		return response;
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/updateEmployee/user/{userId}")
	public ResponseEntity<String> updateEmployee(@PathParam("userId") Long userId, Employee employee) {
		ResponseEntity<String> response;
		
		boolean isUpdated = employeeOperationService.updateEmployeeDetails(userId, employee);
		if(isUpdated) {
			response = new ResponseEntity<>("Updation Succeed!", HttpStatus.OK );		
		}else {
			response = new ResponseEntity<>("updation Failed!", HttpStatus.CONFLICT );
		}
		return response;
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/deleteEmployee/user/{userId}/employeeCode/{employeeCode}")
	public ResponseEntity<String> deleteEmployee(@PathParam("userId") Long userId, @PathParam("employeeCode") Long employeeCode) {
		boolean isDeleted = employeeOperationService.deleteEmployeeDetails(userId, employeeCode);
		ResponseEntity<String> response;
		if(isDeleted) {
			response = new ResponseEntity<>("Deletion Succeed!", HttpStatus.OK );
		}else {
			response = new ResponseEntity<>("Deletion Failed! Employee Not Found", HttpStatus.CONFLICT );
		}
		return response;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/addEmployeeList/user/{userId}")
	public ResponseEntity<String> addEmployees(@PathParam("userId") Long userId, Employee[] employeeList) {
		ResponseEntity<String> response;
		
		boolean isAdded = employeeOperationService.uploadEmployeeList(userId, employeeList);
		if(isAdded) {
			response = new ResponseEntity<>("Addition Succeed!", HttpStatus.CREATED );
		}else {
			response = new ResponseEntity<>("Addition Failed!", HttpStatus.CONFLICT );
		}
		return response;
	}
	
}
