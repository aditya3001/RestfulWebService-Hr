package com.assignment.EmployeeManagementServer.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import com.assignment.EmployeeManagementServer.dto.LoginDto;
import com.assignment.EmployeeManagementServer.interfaces.UserOperationService;

@Path("/userResource")
public class UserResource {
	
	@Autowired
	private UserOperationService userOperationService;
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/userAuth")
	public ResponseEntity<String> login(LoginDto loginUser) {
		return userOperationService.validateUser(loginUser);
	}

}
