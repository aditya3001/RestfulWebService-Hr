package com.assignment.EmployeeManagementServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
